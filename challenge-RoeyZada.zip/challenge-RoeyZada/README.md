# IntSights challenge


## Installation server side:
    cd server 
    npm install

## Installation client side:
    npm install -g @angular/cli (if needed)
    cd ../client
    npm install

## Run server
    cd .. 
    docker-compose build --no-cache
    docker-compose up -d

## Run client dev server
    ng serve

## Web
    goto to http://localhost:4200/

## Loggin server 
    docker-compose logs --tail="15"


## Notes 
    first time (and every time) you run the server, 
    it will initialize data.json file and save this to mongodb.

    im here for any question regarding the challenge 0544931385 Roey 

    thank you for letting me sending this with delay :)
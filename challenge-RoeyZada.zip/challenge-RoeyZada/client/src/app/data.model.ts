

export const SEVERITY: Object = {
    'High': 100,
    'Medium': 70,
    'Low': 40
}


export const TYPE: Object = {
    'VIP': 100,
    'AttackIndication': 80,
    'ExploitableData': 60,
    'BrandSecurity': 40,
    'DataLeakage': 20,
    'Phishing': 10
}
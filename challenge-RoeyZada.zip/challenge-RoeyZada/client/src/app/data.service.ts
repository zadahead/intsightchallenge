import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';



@Injectable({
    providedIn: 'root'
})

export class DataService {

    constructor(private api: HttpClient) { }

    get() {
        const url = "http://localhost:1337/data";
        return this.api.get(url);
    }

    getStats() {

    }
}
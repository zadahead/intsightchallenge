import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-linebar',
  templateUrl: './linebar.component.html',
  styleUrls: ['./linebar.component.scss']
})
export class LinebarComponent implements OnInit {

  @Input() headline: string;
  @Input() value: number;
  @Input() type: string;

  per: number = 0;
  perValue: string = '0';

  constructor() {

  }

  ngOnInit() {
    setTimeout(() => {
      this.per = this.value;
      this.perValue = this.type == 'singleLinebar' ? this.value.toString() + '%' : this.value.toString();
    }, 500);
  }

  getPerValue() {
    return (100 - this.per).toString() + '%';
  }

}

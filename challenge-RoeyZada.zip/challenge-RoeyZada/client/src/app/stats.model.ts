

type linebar = { headline?: string, value: number };
type status = { headline: string, value: number };

type stats = {
    type: string,
    template: string,
    headline: string,
    list: linebar[] | status[]
}[];

export const STATS: stats = [

    {
        template: 'riskmeter',
        type: 'singleLinebar',
        headline: 'System risk meter',
        list: [
            { value: 0 },
        ]
    },

    {
        template: 'cleartypes',
        type: 'status',
        headline: 'clear WEB TYPES',
        list: [
            { headline: 'ATTACK INDICATION', value: 34 },
            { headline: 'DATA LEAKAGE', value: 334 },
            { headline: 'PHISHING', value: 4 },
            { headline: 'brand security', value: 2 },
            { headline: 'exploitable data™', value: 0 },
            { headline: 'vip', value: 0 }
        ]
    },

    {
        template: 'clearseverities',
        type: 'charts',
        headline: 'CLEAR WEB SEVERITIES',
        list: [
            { headline: 'high', value: 466 },
            { headline: 'medium', value: 791 },
            { headline: 'low', value: 1370 }
        ]
    },

    {
        template: 'clearsources',
        type: 'linebar',
        headline: 'CLEAR WEB SOURCES %',
        list: [
            { headline: 'APPLICATION STORES', value: 2 },
            { headline: 'SOCIAL MEDIA', value: 2 },
            { headline: 'PASTE SITES', value: 74 },
            { headline: 'OTHERS', value: 24 }
        ]
    },

    {
        template: 'darktypes',
        type: 'status',
        headline: 'Dark WEB TYPES',
        list: [
            { headline: 'ATTACK INDICATION', value: 34 },
            { headline: 'DATA LEAKAGE', value: 334 },
            { headline: 'PHISHING', value: 4 },
            { headline: 'brand security', value: 2 },
            { headline: 'exploitable data™', value: 0 },
            { headline: 'vip', value: 0 }
        ]
    },

    {
        template: 'darkseverities',
        type: 'charts',
        headline: 'DARK WEB SEVERITIES',
        list: [
            { headline: 'high', value: 63 },
            { headline: 'medium', value: 185 },
            { headline: 'low', value: 126 }
        ]
    },

    {
        template: 'darksources',
        type: 'linebar',
        headline: 'DARK WEB SOURCES %',
        list: [
            { headline: 'BLACK MARKETS', value: 1 },
            { headline: 'HACKING FORUMS', value: 25 },
            { headline: 'PASTE SITES', value: 22 },
            { headline: 'OTHERS', value: 52 }
        ]
    }



];




import { Component, Input, ElementRef, ViewChild, AfterViewInit } from '@angular/core';


enum COLORS {
  "high" = '#D24346',
  "medium" = '#F0AC38',
  "low" = '#4BAFD2'
}


@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.scss']
})

export class ChartsComponent implements AfterViewInit {

  @Input() data: [];

  @ViewChild('canvas', { static: false }) canvas: ElementRef;

  delta: number = 0;
  total: number = 0;
  c: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;

  constructor() { }

  ngAfterViewInit() {
    this.c = <HTMLCanvasElement>this.canvas.nativeElement;
    this.ctx = this.c.getContext("2d");

    this.animate();

  }

  animate() {

    this.data.forEach(it => {
      this.total += it['value'];
    });

    var self = this;
    var curPer = 0;
    var endPer = 100;
    var speed = 3;

    function render() {
      self.ctx.clearRect(0, 0, self.c.width, self.c.height);

      curPer += speed;

      let from = 0;
      self.data.forEach(it => {
        let to = from + (it['value'] / self.total);
        self.drawArc(from * curPer, to * curPer, COLORS[it['headline']]);
        from = to;
      });

      if (curPer <= endPer) {
        requestAnimationFrame(render);
      }
    }
    render();

  }

  drawArc(from: number, to: number, color: string) {
    let fullCircle = Math.PI * 2;

    this.ctx.beginPath();
    this.ctx.arc(this.c.width / 2, this.c.height / 2, 55, fullCircle * (from / 100), fullCircle * (to / 100));
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 10;
    this.ctx.stroke();

  }

}




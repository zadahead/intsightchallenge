import { Component } from '@angular/core';
import { DataService } from './data.service';

import { SEVERITY, TYPE } from './data.model';
import { STATS } from './stats.model';

type riskmatter = { severity: number, type: number };

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [DataService]
})
export class AppComponent {

  riskMatter: number = 0;
  stats: any[];

  constructor(private data: DataService) {
    this.stats = STATS;
  }

  ngOnInit(): void {
    this.setRiskMatter().then(() => {
      //set the riskMatter value
      let mosh = this.stats.filter(it => { return it.template == 'riskmeter' });
      mosh[0]['list'][0]['value'] = this.riskMatter;
    });
  };

  async setRiskMatter(): Promise<void> {

    try {
      let data = await this.getData();

      let rm: riskmatter = { severity: 0, type: 0 };

      data.forEach(al => {
        rm.severity += SEVERITY[al.severity];
        rm.type += TYPE[al.type];
      });

      let s = (rm.severity / data.length); //multiple severity grade with total length
      let t = (rm.type / data.length); //multiple type grade with total length

      let avarage: number = ((s + t) / 2);

      this.riskMatter = Math.round(avarage);

    } catch (error) {
      console.log(error);
    }
  }

  getData(): Promise<any> {
    return new Promise((res, rej) => {
      this.data.get().subscribe((data) => {
        res(data);
      });
    })

  }


}

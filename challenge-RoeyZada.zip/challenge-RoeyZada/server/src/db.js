const MongoClient = require('mongodb').MongoClient;
const fs = require('fs');



// Database Name
const dbName = 'intSights';
const url = 'mongodb://mongodb:27017';

class Mongo {

    constructor() {
        this.db;
        this.COLS = {
            DATA: 'data'
        }
    }

    connect() {
        MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
            console.log(`Connected successfully to Mongo server ${url} -- ${dbName}`);
            if (err) {
                console.log('Err', err);
            } else {
                this.db = client.db(dbName);

                this.init(); //init first time use
            }
        });
    }

    init = async () => {
        console.log('MONGO INIT');

        try {
            let rawdata = fs.readFileSync('src/assets/data.json');
            let data = JSON.parse(rawdata);

            await this.remove(this.COLS.DATA);
            await this.insert(this.COLS.DATA, data);


            console.log("MONGO DB inintialized");
        } catch (error) {
            console.log("ERROR inintialized");
            console.log(error);
        }


    }

    insert(col, rows) {

        return new Promise((res, rej) => {

            const collection = this.db.collection(col);

            if (!rows.length) {
                if (Array.isArray(rows)) {
                    res([]);
                    return;
                } else {
                    rows = [rows];
                }
            }

            // Insert some documents
            collection.insertMany(rows, function (err, result) {
                if (err) {
                    rej(err);
                } else {
                    res(result);
                }
            });
        })
    }

    find(col, params) {
        return new Promise((res, rej) => {

            const collection = this.db.collection(col);

            if (!params.query) { params.query = {}; }
            if (!params.sort) { params.sort = {}; }
            if (!params.skip) { params.skip = 0; }
            if (!params.limit) { params.limit = 0; }

            // Find some documents
            collection.find(params.query).sort(params.sort).skip(params.skip).limit(params.limit).toArray(function (err, docs) {
                if (err) {
                    rej(err);
                } else {
                    res(docs);
                }
            });

        });
    }

    remove(col, query) {
        return new Promise((res, rej) => {
            const collection = this.db.collection(col);

            query = query || {};

            collection.deleteMany(query, function (err, result) {
                if (err) {
                    rej(err);
                } else {
                    res(result);
                }
            });
        });

    }
}


module.exports = new Mongo();


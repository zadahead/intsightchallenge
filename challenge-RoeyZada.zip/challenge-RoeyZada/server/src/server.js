const express = require('express');
var cors = require('cors');
const server = express();
const port = process.env.NODE_PORT || 1337;

const mongo = require('./db');



server.get('/data', cors(), (req, res) => {
    mongo.find(mongo.COLS.DATA, { limit: 300, sort: { date: -1 } }).then(cols => {
        res.json(cols);
    })
})


server.listen(port, () => {
    console.log(`server started on port11 ${port}`)

    console.log('initializing Mongo');
    mongo.connect();

});
